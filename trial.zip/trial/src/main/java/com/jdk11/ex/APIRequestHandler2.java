package com.jdk11.ex;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.UUID;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyRequestEvent;
import com.amazonaws.services.lambda.runtime.events.APIGatewayProxyResponseEvent;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.PutObjectRequest;

public class APIRequestHandler2 implements RequestHandler<APIGatewayProxyRequestEvent, APIGatewayProxyResponseEvent> {
	private static LambdaLogger logger;
	private APIGatewayProxyResponseEvent apiGatewayProxyResponseEvent = new APIGatewayProxyResponseEvent();
	Object requestObject = null;
	String requestString = null;
	String requestMessage = null;
	Integer statusCode;
	APIGatewayProxyResponseEvent apiResp = null;

	public APIGatewayProxyResponseEvent handleRequest(APIGatewayProxyRequestEvent input, Context context) {
		logger = context.getLogger();

		try {
			String requestStringBody = input.getBody();
			JSONParser obj = new JSONParser();
			JSONObject json = (JSONObject) obj.parse(requestStringBody);
			requestObject = json.get("body");
			requestString = requestObject.toString();
			logger.log("Request String is:" + requestString);

			JSONParser parser = new JSONParser();
			JSONObject requestJsonObject = (JSONObject) parser.parse(requestString);
			String requestMessageName = null;
			String requestMessagePhone = null;
			if (requestJsonObject != null && requestJsonObject.containsKey("name")
					&& requestJsonObject.containsKey("phone") && requestJsonObject.size() == 2) {

				if ((requestJsonObject.get("name") != null) && ((String) requestJsonObject.get("name")).length() < 50) {
					requestMessageName = (String) requestJsonObject.get("name");
				} else {
					requestMessage = "Name validation failed!!!";
					statusCode = 400;
					apiResp = generateResponse(apiGatewayProxyResponseEvent, requestMessage, statusCode);
					return apiResp;
				}

				if ((requestJsonObject.get("phone") != null)
						&& ((String) requestJsonObject.get("phone")).length() < 50) {
					requestMessagePhone = (String) requestJsonObject.get("phone");
				} else {
					requestMessage = "Phone validation failed!!!";
					statusCode = 400;
					apiResp = generateResponse(apiGatewayProxyResponseEvent, requestMessage, statusCode);
					return apiResp;
				}

			} else {
				requestMessage = "Name/Phone validation failed!!!";
				statusCode = 400;
				apiResp = generateResponse(apiGatewayProxyResponseEvent, requestMessage, statusCode);
				return apiResp;
			}

			UUID fileUuid = UUID.randomUUID();
			APIRequestHandler2 arh = new APIRequestHandler2();
			apiResp = arh.generatePDF(requestMessageName, requestMessagePhone, fileUuid);
			if (apiResp.getStatusCode() == 200) {
				apiResp = arh.uploadToS3(fileUuid);
			}

			if (apiResp.getStatusCode() == 200) {
				File file = new File("//tmp//" + fileUuid + ".pdf");
				file.delete();
			}

		} catch (ParseException e) {
			e.printStackTrace();
			logger.log(e.getMessage());
		}
		return apiResp;
	}

	private APIGatewayProxyResponseEvent generatePDF(String name, String phone, UUID uuid) {
		try {
			PDDocument pDDocument = PDDocument.load(new File("testpdffields-form-example.pdf"));
			PDAcroForm pDAcroForm = pDDocument.getDocumentCatalog().getAcroForm();
			PDField fieldNm = pDAcroForm.getField("name");
			fieldNm.setValue(name);

			PDField fieldPhn = pDAcroForm.getField("phone");
			fieldPhn.setValue(phone);

			pDDocument.save("//tmp//" + uuid + ".pdf");
			pDDocument.close();
			apiResp = generateResponse(apiGatewayProxyResponseEvent, "PDF generated successfully!!!", 200);
		} catch (IOException ex) {
			apiResp = generateResponse(apiGatewayProxyResponseEvent, "Got an exception while generating pdf!!!", 500);
			return apiResp;
		}
		return apiResp;
	}

	private APIGatewayProxyResponseEvent uploadToS3(UUID uuid) {

		try {
			AmazonS3 client = AmazonS3ClientBuilder.standard().withRegion(Regions.US_EAST_1).build();
			client.putObject(
					new PutObjectRequest("myawsbucket-raghav", uuid + ".pdf", new File("//tmp//" + uuid + ".pdf")));
			logger.log("fileuuid:" + uuid.toString());
			apiResp = generateResponse(apiGatewayProxyResponseEvent, uuid.toString(), 200);
			return apiResp;
		} catch (AmazonServiceException ase) {
			logger.log("Caught an AmazonServiceException, which " + "means your request made it "
					+ "to Amazon S3, but was rejected with an error response" + " for some reason.");
			apiResp = generateResponse(apiGatewayProxyResponseEvent,
					"Caught an AmazonServiceException, which " + "means your request made it "
							+ "to Amazon S3, but was rejected with an error response" + " for some reason.",
							500);
			return apiResp;
		} catch (AmazonClientException ace) {
			logger.log("Caught an AmazonClientException, which " + "means the client encountered "
					+ "an internal error while trying to " + "communicate with S3, "
					+ "such as not being able to access the network.");
			apiResp = generateResponse(apiGatewayProxyResponseEvent,
					"Caught an AmazonClientException, which " + "means the client encountered "
							+ "an internal error while trying to " + "communicate with S3, "
							+ "such as not being able to access the network.",
							500);
			return apiResp;

		}

	}

	public APIGatewayProxyResponseEvent generateResponse(APIGatewayProxyResponseEvent apiGatewayProxyResponseEvent,
			String requestMessage, Integer statusCode) {

		apiGatewayProxyResponseEvent.setHeaders(Collections.singletonMap("timeStamp", String.valueOf(System.currentTimeMillis())));
		apiGatewayProxyResponseEvent.setStatusCode(statusCode);
		apiGatewayProxyResponseEvent.setBody(requestMessage);
		
		return apiGatewayProxyResponseEvent;
	}
}
